using UnityEngine;

public class SpawnerMovement : MonoBehaviour
{
    public Transform PL1;
    public Transform PL2;
    public Transform PL3;
    public GameObject Bl1;
    public GameObject Bl2;
    public GameObject Bl3;
    //public GameObject Bl4;
    public Vector3 np1;
    public Vector3 np2;
    public Vector3 np3;
    //public Vector3 np4;
    public float flySpeed = 2000f;


    void Start()
    {
        // Assuming 'Obstacle' is the tag you want to ignore collisions with
        
    }
    
    void Update()
    {
        MoveObject(PL1);
        MoveObject(PL2);
        MoveObject(PL3);
        Bl1.transform.position = PL1.position + np1;
        Bl2.transform.position = PL2.position + np2;
        Bl3.transform.position = PL3.position + np3;
        //Bl4.transform.position = Player.position + np4;
        //
    }
    void MoveObject(Transform objTransform)
    {
        if (objTransform != null)
        {
            // Move only along the Z-axis
            objTransform.Translate(Vector3.forward * flySpeed * Time.deltaTime);
        }
    }
}

