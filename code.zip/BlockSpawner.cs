using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockSpawner : MonoBehaviour
{
    // Start is called before the first frame update
    public Transform[] SpawnPoints;
    public GameObject ObstaclePrefab;
    public PlayerCollision x;

    public float timetoSpawn = 4f;
    public float timebetweenwaves = 4f;
   
    void Update()
    {
        if(Time.time >= timetoSpawn)
        {
            Spawnblock();
            timetoSpawn = Time.time + timebetweenwaves;
        }

    }
    void Spawnblock()
    {
        int randomIndex = Random.Range(0, SpawnPoints.Length);
        for (int i = 0; i < SpawnPoints.Length; i++)
        {
            if (randomIndex != i)
            {
                Instantiate(ObstaclePrefab, SpawnPoints[i].position, Quaternion.identity);
            }
        }

    }

    // Update is called once per frame
 
}
