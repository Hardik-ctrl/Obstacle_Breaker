using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerMovement : MonoBehaviour
{
    // Start is called before the first frame update
    public Rigidbody rb;
   


    public float forwardforce = 2000f;
    public float SidewaysForce = 500f;

   

    // Update is called once per frame
    void FixedUpdate()
    {
       rb.AddForce(0,0,forwardforce*Time.deltaTime);
   
       if (Input.GetKey(KeyCode.A))
       {
          rb.AddForce(-SidewaysForce*Time.deltaTime, 0, 0,ForceMode.VelocityChange);
       }


       if(Input.GetKey(KeyCode.D))
       {
            rb.AddForce(SidewaysForce*Time.deltaTime, 0, 0, ForceMode.VelocityChange);
       }
       //rb.rotation = Quaternion.Euler(0, rb.rotation.eulerAngles.y, 0);
        if (rb.position.y < -1f)
        {
            // Assuming EndGame is a non-static method in the GameManager script
            GameManager gameManager = FindObjectOfType<GameManager>();
            if (gameManager != null)
            {
                gameManager.EndGame();
                
            }
        }
    }
}
