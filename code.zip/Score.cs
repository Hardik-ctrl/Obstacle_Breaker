using TMPro;
using UnityEngine;

public class Score : MonoBehaviour
{
    public Transform player;
    public TextMeshProUGUI scoreText;
    private float elapsedTime = 0f;

    // Update is called once per frame
    void Update()
    {
        // Increment the elapsed time
        elapsedTime += Time.deltaTime;

        // Update the text with the calculated score (elapsed time)
        scoreText.text = elapsedTime.ToString("0");
    }

    // Called when the game is restarted
    public void ResetScore()
    {
        // Reset the elapsed time to 0
        elapsedTime = 0f;

        // Update the text with the reset score
        scoreText.text = "0";
    }
}
