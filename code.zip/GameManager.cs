using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    bool gameHasEnded = false;
    float RestartDelay = 2f;

    public void EndGame()
    {
        if (!gameHasEnded)
        {
            gameHasEnded = true;
            Debug.Log("End Game");
            Invoke("Restart", RestartDelay);

            // Corrected syntax to find the Score script and call ResetScore
            FindObjectOfType<Score>().ResetScore();
        }
    }

    void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
